#include <stdlib.h>
#include "linked_list.h"

int list_find_student(list_t *list, int value) {
    if (list == NULL) {
        return -1;
    }
    node_t *c = list->head;
    for (int i = 0; i < list->size; i++) {
        if (c->value == value) {
            return i;
        }
        c = c->next;
    }
    return -1;   // TODO Implement a better version of list search here
}

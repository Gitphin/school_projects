#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "contacts.h"

// This is the (somewhat famous) djb2 hash
unsigned hash(const char *str) {
    unsigned hash_val = 5381;
    int i = 0;
    while (str[i] != '\0') {
        hash_val = ((hash_val << 5) + hash_val) + str[i];
        i++;
    }
    return hash_val % NUM_BUCKETS;
}

contacts_log_t *create_contacts_log(const char *log_name) {
    contacts_log_t *new_log = malloc(sizeof(contacts_log_t));
    if (new_log == NULL) {
        return NULL;
    }

    strcpy(new_log->log_name, log_name);
    for (int i = 0; i < NUM_BUCKETS; i++) {
        new_log->buckets[i] = NULL;
    }
    new_log->size = 0;

    return new_log;
}

const char *get_contacts_log_name(const contacts_log_t *log) {
    // TODO Not yet implemented
    return NULL;
}

int add_contact(contacts_log_t *log, const char *name, unsigned long phone_number, unsigned zip_code) {
    // TODO Not yet implemented
    return 0;
}

long find_phone_number(const contacts_log_t *log, const char *name) {
    // TODO Not yet implemented
    return 0;
}

void print_contacts_log(const contacts_log_t *log) {
    // TODO Not yet implemented
}

void free_contacts_log(contacts_log_t *log) {
    // TODO Not yet implemented
}

int write_contacts_log_to_text(const contacts_log_t *log) {
    char file_name[MAX_NAME_LEN + strlen(".txt")];
    strcpy(file_name, log->log_name);
    strcat(file_name, ".txt");
    FILE *f = fopen(file_name, "w");
    if (f == NULL) {
        return -1;
    }

    fprintf(f, "%u\n", log->size);
    for (int i = 0; i < NUM_BUCKETS; i++) {
        node_t *current = log->buckets[i];
        while (current != NULL) {
            fprintf(f, "%s %lu %u\n", current->name, current->phone_number, current->zip_code);
            current = current->next;
        }
    }
    fclose(f);
    return 0;
}

contacts_log_t *read_contacts_log_from_text(const char *file_name) {
    // TODO Not yet implemented
    return NULL;
}

int write_contacts_log_to_binary(const contacts_log_t *log) {
    // TODO Not yet implemented
    return 0;
}

contacts_log_t *read_contacts_log_from_binary(const char *file_name) {
    // TODO Not yet implemented
    return NULL;
}

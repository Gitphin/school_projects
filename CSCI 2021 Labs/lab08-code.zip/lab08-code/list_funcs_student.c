#include <stdlib.h>
#include "linked_list.h"

int list_find_student(list_t *list, int value) {
    // TODO Implement a better version of list search here
    return -1;
}
